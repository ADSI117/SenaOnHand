<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rol extends Model {

    /**
     * Generated
     */

    protected $table = 'tb_roles';
    protected $fillable = ['id', 'descripcion'];



}
