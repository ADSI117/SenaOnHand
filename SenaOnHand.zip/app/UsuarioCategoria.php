<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsuarioCategoria extends Model
{
    protected $table = 'usuario_categoria';
}
