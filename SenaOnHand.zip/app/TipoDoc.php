<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoDoc extends Model {

    /**
     * Generated
     */

    protected $table = 'tb_tipo_doc';
    protected $fillable = ['id', 'nombre'];



}
