<div class="list-group">
  <a class="list-group-item list-group-item-action" href="{{ route('tipos_denuncias.index') }}">Tipos denuncias</a>
  <a class="list-group-item list-group-item-action" href="{{ route('estados_usuarios.index') }}">Estados usuarios</a>
  <a class="list-group-item list-group-item-action" href="{{ route('estados_comentarios.index') }}">Estados comentarios</a>
  <a class="list-group-item list-group-item-action" href="{{ route('estados_denuncias.index') }}">Estados denuncias</a>
  <a class="list-group-item list-group-item-action" href="{{ route('estados_publicaciones.index') }}">Estados publicaciones</a>
  <a class="list-group-item list-group-item-action" href="{{ route('tipos_anuncios.index') }}">Tipos anuncios</a>
  <a class="list-group-item list-group-item-action" href="{{ route('tipos_docs.index') }}">Tipos documentos</a>
  <a class="list-group-item list-group-item-action" href="{{ route('roles.index') }}">Roles</a>
  <a class="list-group-item list-group-item-action" href="{{ route('regionales.index') }}">Regionales</a>
  <a class="list-group-item list-group-item-action" href="{{ route('centros.index') }}">Centros</a>
  <a class="list-group-item list-group-item-action" href="{{ route('sedes.index') }}">Sedes</a>
  <a class="list-group-item list-group-item-action" href="{{ route('programas.index') }}">Programas</a>
  <a class="list-group-item list-group-item-action" href="{{ route('categorias.index') }}">Categorias</a>
  <a class="list-group-item list-group-item-action" href="{{ route('subcategorias.index') }}">Subcategorias</a>
</div>
{{-- <a href="#" class="list-group-item active">
Cras justo odio
</a>
<a href="#" class="list-group-item list-group-item-action">Dapibus ac facilisis in</a>
<a href="#" class="list-group-item list-group-item-action disabled">Vestibulum at eros</a> --}}
