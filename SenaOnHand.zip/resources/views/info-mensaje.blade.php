<h1>Mensaje: </h1>
<h2>Debe activar su cuenta</h2>
