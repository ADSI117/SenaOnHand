<!-- Notificaciones del usuario -->



<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <h3>Sus notificaciones</h3>
    <div class="row">
      <div class="col-md-6">
        <h4>No leidas</h4>
        <div class="list-group">
          <?php $__currentLoopData = $noleidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noleida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group-item">
              <!-- <?php echo e(var_dump($noleida->data)); ?> -->
              <a href="<?php echo e($noleida->data['link']); ?>"><?php echo e($noleida->data['text']); ?></a>

              <?php echo Form::open(['route'=>['notificaciones.update', $noleida], 'method' => 'POST']); ?>

                <?php echo e(method_field('PATCH')); ?>

                <?php echo e(csrf_field()); ?>

                <?php echo Form::submit('x', ['class' => 'btn btn-danger btn-xs']); ?>

              <?php echo Form::close(); ?>


            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


      </div>

      <div class="col-md-6">
        <h4>Leidas</h4>
        <div class="list-group">
          <?php $__currentLoopData = $leidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($leida->data['link']); ?>"><?php echo e($leida->data['text']); ?></a>

            <?php echo Form::open(['route'=>['notificaciones.destroy', $leida->id], 'method' => 'DELETE']); ?>


              <?php echo Form::submit('x', ['class' => 'btn btn-danger btn-xs']); ?>

            <?php echo Form::close(); ?>


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>