<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('main'); ?>
  
  <div class="page-header-image" style="background-image:url(<?php echo e(asset('imagenes/background/fondo_1.jpg')); ?>)"></div>
    <div class="container">
      <div class="row full-h justify-content-center align-items-center">
      <div class="col-md-4">

        <div class="card card-login pl-5 pr-5">
          <form class="form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
            <div class="header header-primary text-center">
              <h4 class="title title-up">Inicio</h4>
            </div>
            <hr />
            <div class="content">
              <?php echo e(csrf_field()); ?>

              <div class="input-group input-lg">
                <span class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                </span>
                <input id="email" type="email" pattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" class="form-control" name="email" placeholder="Correo electronico" required>
              </div>

              <div class="input-group input-lg">
                <span class="input-group-addon">
                    <i class="fa fa-unlock-alt"></i>
                </span>
                <input id="password" type="password" class="form-control" name="password" placeholder="Clave" required>
              </div>

            </div>
            <div class="footer text-center mt-2">
              <div class="checkbox">
                <input id="checkbox1" type="checkbox" name="remember"  <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label for="checkbox1">
                  Recordarme
                </label>
              </div>
              <button type="submit" class="btn btn-primary btn-round">
                  Ingresar
              </button>
              <br /> <br />
              <a class="link" href="<?php echo e(route('password.request')); ?>">
                ¿Olvidó su contraseña?
              </a>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>