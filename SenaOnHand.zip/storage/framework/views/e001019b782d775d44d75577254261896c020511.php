<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>

  <?php echo Form::open(['route' => ['usuarios.update', $usuario] , 'method' => 'PUT', 'files' => true]); ?>

  <div class="page-banner bg-brown">
    <div class="container">
      <h1>
        Editar perfil
      </h1>
    </div>
    <div class="btn-float-page">
      <button type="submit" class="btn btn-info btn-icon btn-round">
        <i class="fa fa-floppy-o"></i>
      </button>
    </div>
  </div>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xs-12 col-md-6">
        <div class="form-group">
          <label for="nombres">Nombre: </label>
          <?php echo Form::text('nombres', $usuario->nombres,
            ['id' => 'nombres', 'placeholder' => 'Escriba su nombre', 'required', 'class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Apellido: </label>
            <?php echo Form::text('apellidos', $usuario->apellidos, ['id' => 'apellidos', 'placeholder' => 'Escriba su apellido', 'required', 'class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Profesion: </label>
            <?php echo Form::text('profesion', $usuario->profesion, ['id' => 'profesion', 'placeholder' => 'Escriba su profesion', 'required', 'class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Tipo de documento: </label>
            <?php echo Form::select('tipo_doc_id', $tipos_doc, $usuario->tipo_doc_id, ['class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Número de documento: </label>
            <?php echo Form::number('num_doc', $usuario->num_doc, ['id' => 'num_doc', 'placeholder' => 'Escriba su num de doc', 'required', 'class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Fecha de nacimiento: </label>
            <?php echo Form::date('fecha_nac', $usuario->fecha_nac, ['id' => 'fecha_nac', 'required', 'class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Sede: </label>
            <?php echo Form::select('sede_id', $sedes, $usuario->sede_id, ['class' => 'form-control']); ?>

          </div>
          <div class="form-group">
            <label for="nombres">Grupo: </label>
            <?php echo Form::select('grupo_id', $grupos, $usuario->grupo_id, ['class' => 'form-control']); ?>

          </div>

        </div>
        <div class="col-xs-12 col-md-4">
          <?php echo Form::label('Imagen de perfil'); ?>

          <?php echo Form::file('imagen', ['class' => 'form-control']); ?>

          <div class="photo-container">
            <img src="<?php echo e(url('/')); ?>/imagenes/perfiles/<?php echo e($usuario->url_foto); ?>" alt="Foto de perfil" />
          </div>
          <div>
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
      </div>
    </div>

    <?php echo Form::close(); ?>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>