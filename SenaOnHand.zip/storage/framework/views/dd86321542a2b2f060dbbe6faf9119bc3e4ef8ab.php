<!-- Detalle de mensajes -->



<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-12">
        <h3>Mensajes</h3>

        <p><?php echo e($mensaje->mensaje); ?></p>
        <small>Enviado por: <?php echo e($mensaje->user->nombres); ?></small>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>