<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>

  <div class="page-banner bg-indigo">
    <div class="container">
      <h1>
        Últimas publicaciones
      </h1>
    </div>
  </div>

  <div class="container">
    <div class="row justify-content-center">
      

      <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-sm-10 col-md-6 col-lg-4">
          <div class="tarjeta">
            <h4 class="cabezera">
              <a href="<?php echo e(route('publicaciones.show', [$publicacion->id])); ?>"><?php echo e($publicacion->titulo); ?></a>
              <small class="text-muted">
                <a href="<?php echo e(route('instructores.show', [$publicacion->user_id])); ?>">
                  <?php echo e($publicacion->user->nombres); ?> <?php echo e($publicacion->user->apellidos); ?>

                </a>
              </small>

              <div class="imagen">
                <img src="<?php echo e(url('/')); ?>/imagenes/perfiles/<?php echo e($publicacion->user->url_foto); ?>" class="rounded-circle" width="60" height="60">
              </div>
            </h4>


            <div class="contenido">
              <p><?php echo e(substr($publicacion->contenido, 0, 140)); ?> ... </p>
            </div>

          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="row mt-3">
      <div class="col">
        <div class="text-center"><?php echo e($publicaciones->links('vendor.pagination.custom')); ?></div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>