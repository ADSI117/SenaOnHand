<?php $__env->startSection('title'); ?>
  <?php echo $__env->yieldContent('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

  <div class="row">
    <div class="col">
      <?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row">
    <div class="col" style="padding-right:0px;">
      <div style="min-height: calc(100vh - 62px);max-height: calc(100vh - 62px);overflow-y: scroll;">
        <?php echo $__env->make('template.v-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
    <div class="col-10">
      <div class="container pt-5">
        <div class="row justify-content-center">
          <div class="col-6">
            <h3 class="title-header">
              <?php echo $__env->yieldContent('title-content'); ?>
            </h3>
          </div>
          <?php echo $__env->yieldContent('search-content'); ?>
        </div>
        <div class="row justify-content-center">
          <div class="col-10">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-control'); ?>
  <?php echo $__env->yieldContent('modal-control'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <?php echo $__env->yieldContent('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>