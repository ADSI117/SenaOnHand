<?php $__env->startSection('title','Tipos anuncios'); ?>

<?php $__env->startSection('title-content', 'Tipos de anuncios'); ?>

<?php $__env->startSection('search-content'); ?>
	<div class="col-4">
		<div class="search-content">
		<!-- BUSCADOR -->
		<?php echo Form::open(['route'=>'tipos_anuncios.index', 'method'=>'GET','class' => 'f-right form-search']); ?>

		<div class="input-group">
			<?php echo Form::text('descripcion', null,
				['placeholder' => 'Buscar...', 'class' => 'form-control', 'id' => 'buscar_tipo_anuncio']); ?>

				<span class="input-group-addon">
					<i class="fa fa-search" aria-hidden="true"></i>
				</span>
			</div>
			<?php echo Form::close(); ?>

			<!--  FIN BUSCADOR -->
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Colored FAB button -->
	<div class="btn-float">
			<button data-toggle="modal" data-target="#modal-control"
			data-action="<?php echo e(route('tipos_anuncios.store')); ?>"
			data-method="POST"
			onclick="showModalAccion(this.dataset)"
			class="btn btn-danger btn-icon btn-round">
			<i class="fa fa-plus"></i>
		</button>
	</div>

<table class="table table-hover" id="table">
<thead>
  <tr>
    <th class="ta-left">Id</th>
    <th class="ta-left">Tipo de Anuncio</th>
    <th class="ta-right">Acciones</th>
  </tr>
</thead>
<tbody>
	<?php $__currentLoopData = $tipos_anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr data-tr="<?php echo e($tipo_anuncio->id); ?>">
			<td class="align-middle"><?php echo e($tipo_anuncio->id); ?></td>
			<td class="align-middle"><?php echo e($tipo_anuncio->nombre); ?></td>

			<td class="ta-right">
        <button
							data-toggle="modal" data-target="#modal-control"
							data-action="<?php echo e(route('tipos_anuncios.update', $tipo_anuncio)); ?>"
							data-method="PUT"
							data-td="<?php echo e($tipo_anuncio->id); ?>"
							onclick="showModalAccion(this.dataset)"
							class="btn btn-warning btn-icon  btn-icon-mini btn-round">
								<i class="fa fa-pencil" aria-hidden="true"></i>
						</button>
				<?php echo e(Form::open(['class'=>'d-ib m-0','method' => 'DELETE', 'route' =>
        ['tipos_anuncios.destroy', $tipo_anuncio->id]])); ?>

        <button type="submit" class="btn btn-danger btn-icon btn-icon-mini btn-round">
          <i class="fa fa-trash" aria-hidden="true"></i>
        </button>
        <?php echo e(Form::close()); ?>

			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo $tipos_anuncios->links('vendor.pagination.custom'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal-control'); ?>
	
	<?php $__env->startSection('modal-title','tipos de anuncios'); ?>
	<?php $__env->startSection('modal-content'); ?>
		<?php echo Form::open(['id' => 'form-accion']); ?>

		<div class="modal-body">
		    <div class="form-group">
					<?php echo Form::text('nombre',null,
						['placeholder' => 'Nombre' ,
						 	'required',
							'class' => 'form-control',
							'id' => 'nombre']); ?>

		    </div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Cancelar</button>
			<button type="submit" name="btnSubmit" class="btn btn-info btn-simple">Registrar</button>
			
		</div>
		<?php echo Form::close(); ?>

	<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script src="<?php echo e(asset('js/tipos_anuncios.js')); ?>" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>