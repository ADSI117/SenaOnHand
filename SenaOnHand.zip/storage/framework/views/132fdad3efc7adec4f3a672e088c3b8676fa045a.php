<div class="list-group">
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('tipos_denuncias.index')); ?>">Tipos denuncias</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('estados_usuarios.index')); ?>">Estados usuarios</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('estados_comentarios.index')); ?>">Estados comentarios</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('estados_denuncias.index')); ?>">Estados denuncias</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('estados_publicaciones.index')); ?>">Estados publicaciones</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('tipos_anuncios.index')); ?>">Tipos anuncios</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('tipos_docs.index')); ?>">Tipos documentos</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('roles.index')); ?>">Roles</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('regionales.index')); ?>">Regionales</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('centros.index')); ?>">Centros</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('sedes.index')); ?>">Sedes</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('programas.index')); ?>">Programas</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('categorias.index')); ?>">Categorias</a>
  <a class="list-group-item list-group-item-action" href="<?php echo e(route('subcategorias.index')); ?>">Subcategorias</a>
</div>

