<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>
<!-- Mostrar listado de categorias iniciales para que el usuario haga primeros pasos -->

<div class="container">
  <div class="row">
    <h1>Primeros pasos</h1>
    <h3>Selecciona algunos de tus intereses para comenzar</h3>
  </div>
  <div class="row">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xs-12 col-md-4">
      <div class="card" style="width: 20rem;">
        <!-- <div class="card-img-top" style="padding: 20px;">
          <h1>HOla</h1>
        </div> -->
        <div class="card-block">
          <h4 class="card-title"><span class="badge badge-default"><?php echo e($categoria->descripcion); ?></span></h4>
          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <?php echo Form::open(['route'=>'categoria-usuario.store', 'method' => 'POST']); ?>

          <?php echo Form::hidden('categoria_id', $categoria->id); ?>

          <?php echo Form::submit('Seguir', ['class'=>'btn btn-primary']); ?>

          <?php echo Form::close(); ?>

        </div>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <div class="row">
    <a href="<?php echo e(route('main-panel')); ?>" class=" btn btn-danger btn-block">Saltar este paso</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>