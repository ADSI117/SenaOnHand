<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>

  <div class="container">
    <div class="row justify-content-center">

      <?php echo Form::open(['route' => ['publicaciones.update', $publicacion], 'method' => 'PUT', 'files' => true, 'class' => 'form']); ?>

      <div class="header header-primary text-center">
        <h4 class="title title-up" >Editar publicacion</h4>
      </div>

      <div class="form-group form-group-no-border">
        
        <?php echo Form::text('titulo', $publicacion->titulo, ['id' => 'nombre', 'placeholder' => 'Título', 'required', 'class' => 'form-control']); ?>

      </div>
      <div class="form-group form-group-no-border ">
        <?php echo Form::textarea('contenido', $publicacion->contenido,
          ['id' => 'contenido', 'rows' => '5', 'placeholder' => 'Contenido de la pubicación', 'required', 'class' => 'form-control']); ?>

        </div>

        <div class="form-group form-group-no-border ">
          <?php echo Form::label('imagen', 'Imagen'); ?>

          <?php echo Form::file('imagen', ['class' => 'form-control']); ?>

        </div>

        <div class="form-group form-group-no-border ">
          <?php echo Form::label('archivo', 'Archivo'); ?>

          <?php echo Form::file('archivo', ['class' => 'form-control']); ?>

        </div>

        <div class="form-group form-group-no-border">
          <?php echo Form::label('video', 'Video'); ?>

          <?php echo Form::text('video', null, ['id' => 'video', 'placeholder' => 'URL del video', 'class' => 'form-control']); ?>

        </div>

        <div class="form-group form-group-no-border">
          <?php echo Form::select('subcategoria_id', $subcategorias, $publicacion->subcategoria_id, ['placeholder' => 'Seleccione una Subcategoria', 'required', 'class' => 'form-control']); ?>

        </div>
        <div class="form-group form-group-no-border">
          <?php echo Form::select('estado_id', $estados, $publicacion->estado_id, ['placeholder' => 'Estado publicacion', 'required', 'class' => 'form-control']); ?>

        </div>
        <div class="form-group form-group-no-border">
          <?php echo Form::select('tags', $tags, $publicacion->tags, ['multiple'=>'multiple', 'name'=>'tags[]',  'required', 'class' => 'form-control']); ?>

        </div>

        <div class="text-center">
          <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>


        <p>
          <?php if($publicacion->tags->all()): ?>
            <h3>Tags</h3>
              <?php $__currentLoopData = $publicacion->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php echo Form::open(['method' => 'DELETE', 'route' => ['tags.destroy', $tag->id]]); ?>

                  <?php echo e($tag->descripcion); ?>

                  <!-- Corregir modo hidden -->
                  <?php echo Form::text('publicacion_id', $publicacion->id, ['class'=>'invisible']); ?>

                  <?php echo Form::button('Borrar', ['class' => 'btn btn-warning', 'type' => 'submit']); ?>

                <?php echo Form::close(); ?>


              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </p>
        <br>

        <p>
          <?php if($publicacion->imagenes->all()): ?>
            <h3>Imagenes</h3>
            <?php $__currentLoopData = $publicacion->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php echo Form::open(['method' => 'DELETE', 'route' => ['imagenes.destroy', $imagen->id]]); ?>

                <img src="/imagenes/publicaciones/<?php echo e($imagen->descripcion); ?>" alt="" width="150" height="150">
                <?php echo Form::button('Borrar', ['class' => 'btn btn-warning', 'type' => 'submit']); ?>

              <?php echo Form::close(); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </p>

        <br>

        <!-- Desplegar archivos que tiene la publicacion -->
        <p>
          <?php if($publicacion->archivos->all()): ?>
            <h3>Archivos</h3>
            <?php $__currentLoopData = $publicacion->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php echo Form::open(['method' => 'DELETE', 'route' => ['archivos.destroy', $archivo->id]]); ?>

              <!-- TODO: como mostrar los archivos -->
              <?php echo e($archivo->descripcion); ?>

                <!-- <img src="/imagenes/publicaciones/<?php echo e($imagen->descripcion); ?>" alt="" width="150" height="150"> -->
                <?php echo Form::button('Borrar', ['class' => 'btn btn-warning', 'type' => 'submit']); ?>

              <?php echo Form::close(); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </p>

        <br>

        <!-- Desplegar VIDEOS que tiene la publicacion -->
        <p>
          <?php if($publicacion->videos->all()): ?>
            <h3>Videos</h3>
            <?php $__currentLoopData = $publicacion->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php echo Form::open(['method' => 'DELETE', 'route' => ['videos.destroy', $video->id]]); ?>

              <!-- TODO: como mostrar los videos -->
              <iframe width="560" height="315" src="<?php echo e($video->descripcion); ?>" frameborder="0" allowfullscreen></iframe>
                <!-- <img src="/imagenes/publicaciones/<?php echo e($imagen->descripcion); ?>" alt="" width="150" height="150"> -->
                <?php echo Form::button('Borrar', ['class' => 'btn btn-warning', 'type' => 'submit']); ?>

              <?php echo Form::close(); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </p>

      </div>
    </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>