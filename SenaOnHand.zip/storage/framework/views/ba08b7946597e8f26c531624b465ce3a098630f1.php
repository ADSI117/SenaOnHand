<!-- Modal Core -->
<div class="modal fade" id="modal-control" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
        <i class="now-ui-icons ui-1_simple-remove"></i>
      </button>
      <h4 class="modal-title title-header"><?php echo $__env->yieldContent('modal-title'); ?></h4>
    </div>
    <?php echo $__env->yieldContent('modal-content'); ?>
    
  </div>
</div>
</div>
