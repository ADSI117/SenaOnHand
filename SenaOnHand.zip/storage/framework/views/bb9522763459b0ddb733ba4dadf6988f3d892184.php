<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>
  <div class="page-banner" style="background-color:#2196F3;">
    <div class="container">
      <h1>
        <?php echo e($publicacion->titulo); ?>

      </h1>
      <div class="d-flex">
        <img  class="mr-3"
              src="<?php echo e(url('/')); ?>/imagenes/perfiles/<?php echo e($publicacion->user->url_foto); ?>"
              alt="foto de perfil"
              width="50" height="50"/>
        <span class="d-flex align-items-center">
          Autor:
          <a href="<?php echo e(route('instructores.show', [$publicacion->user_id])); ?>" class="link-autor">
            <?php echo e($publicacion->user->nombres); ?> <?php echo e($publicacion->user->apellidos); ?>

          </a>
        </span>
      </div>
    </div>
    <?php if(Auth::user()->id == $publicacion->user_id): ?>
    <div class="btn-float-page">
      <a href="<?php echo e(route('publicaciones.edit', $publicacion->id)); ?>" class="btn btn-warning btn-icon btn-round">
        <i class="fa fa-pencil"></i>
      </a>
    </div>
    <?php endif; ?>
  </div>
  <div class="container mb-5">

    <div class="row">

      <div class="col-6 justify-content-start">
        Fecha creado: <?php echo e(date('Y-m-d', strtotime($publicacion->created_at))); ?>

        <br />
        
      </div>
      <div class="col-6 justify-content-end">
        <form id="form">
          <p class="clasificacion">
            <input id="radio1" type="radio" name="estrellas" value="5"><!--
            --><label for="radio1">★</label><!--
            --><input id="radio2" type="radio" name="estrellas" value="4"><!--
            --><label for="radio2">★</label><!--
            --><input id="radio3" type="radio" name="estrellas" value="3"><!--
            --><label for="radio3">★</label><!--
            --><input id="radio4" type="radio" name="estrellas" value="2"><!--
            --><label for="radio4">★</label><!--
            --><input id="radio5" type="radio" name="estrellas" value="1"><!--
            --><label for="radio5">★</label>
          </p>
        </form>
      </div>

      <div class="w-100"></div>

      <div class="col">
        <h4 class="display-4"><?php echo e($publicacion->titulo); ?></h4>
        <p class="lead pt-2">
          <?php echo e($publicacion->contenido); ?>

        </p>
        <?php if($imagenes): ?>
          <h3>Imagenes</h3>
          <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(url('/')); ?>/imagenes/publicaciones/<?php echo e($imagen->descripcion); ?>" alt="" width="150" height="150">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div>
          <?php if($publicacion->archivos->all()): ?>
            <h3>Archivos</h3>
            <?php $__currentLoopData = $publicacion->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <!-- TODO: como mostrar los archivos -->
              <?php echo e($archivo->descripcion); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
        <?php if($publicacion->videos->all()): ?>
        <div class="p-5">
            <div class="embed-responsive embed-responsive-21by9">
            <?php $__currentLoopData = $publicacion->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- TODO: como mostrar los videos -->
                <iframe class="embed-responsive-item" src="<?php echo e($video->descripcion); ?>" frameborder="0" allowfullscreen></iframe>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php endif; ?>

      </div>

      <div class="w-100"></div>

      <div class="col mt-4">
        <h5>tags</h5>
        <span class="chip">
          <?php echo e($publicacion->subcategoria->descripcion); ?>

        </span>
        <span class="chip">
          <?php echo e($publicacion->subcategoria->categoria->descripcion); ?>

        </span>
        <?php if($publicacion->tags): ?>
          <?php $__currentLoopData = $publicacion->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="chip">
              <?php echo e($tag->descripcion); ?>

            </span>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </div>

    </div>

</div>

<hr>

<div class="container">
  <div>
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="row">
    <div class="col-xs-12">
      <h3>Comentarios</h3>
      <!-- Formulario para comentarios. -->
      <?php echo Form::open(['route'=>'comentarios.store', 'method' => 'POST']); ?>

        <div class="form-group">
          <?php echo Form::hidden('publicacion_id', $publicacion->id); ?>

          <?php echo Form::textarea('comentario', null, ['plcaholder'=>'Ingresa tu comentario', 'class'=>'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::submit('Enviar', ['class'=>'btn btn-primary']); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<hr>
<div class="container">
  <div class="row">
    <div class="col-xs-12">
      <h3>Listado</h3>
      <?php $__currentLoopData = $publicacion->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span><?php echo e($comentario->comentario); ?></span>
        <small>Publicado por: <?php echo e($comentario->user->nombres); ?></small>
        <?php echo Form::open(['route'=>'denuncias.store', 'method' => 'POST']); ?>

        <?php echo Form::hidden('comentario_id', $comentario->id); ?>

        <?php echo Form::hidden('publicacion_id', $publicacion->id); ?>

        <!-- TODO: Hacer el siguiente campo visible cuando se termine el frontend -->
        <?php echo Form::text('comentario', 'Comentario', ['class' => 'form-control']); ?>

        <?php echo Form::select('tipo_denuncia', $tipos_denuncias, $comentario->tipo_id, ['class'=>'form-control']); ?>


        <br>
        <?php echo Form::submit('Denunciar', ['class'=>'btn btn-primary']); ?>

        <?php echo Form::close(); ?>


        <!-- Formulario de eliminacion -->
        <?php if(Auth::user()->id == $comentario->usuario_id || Auth::user()->id == $publicacion->usuario_id || Auth::user()->rol_id == 3): ?>
          <?php echo Form::open(['route' => ['comentarios.destroy', $comentario->id], 'method' => 'DELETE']); ?>

          <?php echo Form::submit('Eliminar', ['class'=>'btn btn-primary']); ?>

          <?php echo Form::close(); ?>

        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <br><br><br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>