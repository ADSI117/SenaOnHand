<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>


  <?php echo Form::open(['route' => 'publicaciones.store', 'method' => 'POST', 'files' => true, 'class' => '']); ?>

  <div class="page-banner">
    <div class="container">
      <h1>Nueva publicacion</h1>
    </div>
    <div class="btn-float-page">
      <button type="submit" class="btn btn-info btn-icon btn-round">
        <i class="fa fa-floppy-o"></i>
      </button>
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-sm-12 col-md-7 ">
        <div class="card">

          <div class="card-block">
            <div class="form-group form-group-no-border">
              <?php echo Form::label('titulo', 'Titulo'); ?>

              <?php echo Form::text('titulo', null, ['id' => 'nombre', 'placeholder' => 'Título', 'required', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group form-group-no-border ">
              <?php echo Form::label('contenido', 'Contenido'); ?>

              <?php echo Form::textarea('contenido', null, ['id' => 'contenido', 'rows' => '5', 'placeholder' => 'Contenido de la pubicación', 'required', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group form-group-no-border">
              <?php echo Form::select('subcategoria_id', $subcategorias, null, ['placeholder' => 'Seleccione una Subcategoria', 'required', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group form-group-no-border">
              <?php echo Form::select('estado_id', $estados, null, ['placeholder' => 'Estado publicacion', 'required', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group form-group-no-border">
              <?php echo Form::select('tags', $tags, null, ['multiple'=>'multiple', 'name'=>'tags[]',  'required', 'class' => 'form-control']); ?>

            </div>
          </div>
        </div>

      </div>
      <div class="col-sm-12 col-md-5 col-lg-4">
        <div class="form-group form-group-no-border ">
          <?php echo Form::label('imagen', 'Imagen'); ?>

          <?php echo Form::file('imagen', ['class' => 'form-control']); ?>

        </div>
        <div class="form-group form-group-no-border ">
          <?php echo Form::label('archivo', 'Archivo'); ?>

          <?php echo Form::file('archivo', ['class' => 'form-control']); ?>

        </div>

        <div class="form-group form-group-no-border">
          <?php echo Form::label('video', 'Video'); ?>

          <?php echo Form::text('video', null, ['id' => 'video', 'placeholder' => 'URL del video', 'class' => 'form-control', 'type', 'url']); ?>

        </div>

        <div class="embed-responsive embed-responsive-16by9" id="video-container">
          
        </div>

      </div>
    </div>
    <?php echo Form::close(); ?>

  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/cargarvideo.js')); ?>"></script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>