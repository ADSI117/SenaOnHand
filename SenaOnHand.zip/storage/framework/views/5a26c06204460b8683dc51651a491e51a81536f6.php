<?php echo $__env->make('template.h-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6">
        <h2>Mis categorias</h2>

        <?php $__currentLoopData = $usuario->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e(Form::open(['method' => 'DELETE', 'route' => ['categoria-usuario.destroy', $categoria->id]])); ?>

          <a href="#"><?php echo e($categoria->descripcion); ?></a>
          <?php echo Form::submit('Sejar de seguir', ['class'=>'btn btn-warning']); ?>

          <?php echo e(Form::close()); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>

    <div class="row">
      <div class="col-xs-12 col-md-6">
        <h2>Instructores</h2>

        <?php $__currentLoopData = $usuario->seguidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seguido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e(Form::open(['method' => 'DELETE', 'route' => ['seguidos.destroy', $seguido->id]])); ?>

          <?php if($seguido->seguido->url_foto): ?>
            <img src="<?php echo e(url('/')); ?>/imagenes/perfiles/<?php echo e($seguido->seguido->url_foto); ?>" alt="" width="50" height="50">
          <?php else: ?>
            <img src="<?php echo e(url('/')); ?>/imagenes/perfiles/soh_profile_default.png" alt="" width="50" height="50">
          <?php endif; ?>
          <a href="#"><?php echo e($seguido->seguido->nombres); ?> <?php echo e($seguido->seguido->apellidos); ?></a>

          <?php echo Form::submit('Sejar de seguir', ['class'=>'btn btn-warning']); ?>

          <?php echo e(Form::close()); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>